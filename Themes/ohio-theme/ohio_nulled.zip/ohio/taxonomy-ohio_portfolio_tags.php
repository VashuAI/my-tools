<?php
/**
 * Ohio WordPress Theme
 *
 * Tag taxonomy template
 *
 * @author Colabrio
 * @link   https://ohio.clbthemes.com
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'taxonomy', 'ohio_portfolio_category' );