<?php

/**
* WPBakery Page Builder Ohio Carousel Inner shortcode view
*/

?>
<div class="slider-wrap">

	<?php echo do_shortcode( $content_html ); ?>
	
</div>