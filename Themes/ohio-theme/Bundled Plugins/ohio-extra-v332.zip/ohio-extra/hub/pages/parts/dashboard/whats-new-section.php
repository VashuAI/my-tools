<h2 class="clb-headline"><?php _e( 'What’s New', 'ohio-extra' ); ?></h2>

<!-- Group 2cl -->
<div class="clb-group">
	<div class="clb-group-headline">
		<h3><?php _e( 'Release Notes', 'ohio-extra' ); ?></h3>
		<a target="_blank" href="https://docs.clbthemes.com/ohio/release-notes/" class="btn btn-flat"><?php _e( 'All Changelog', 'ohio-extra' ); ?></a>
	</div>
	<div class="clb-group-details">
		# [Ver 3.3.2] – October 25, 2023
	</div>
	<div class="clb-group-content">
		<pre>
## Fixed
- Minor style fixes and improvements;

## Added
- Option to set a blog post layout for each post;
- Option to choose the subscribe popup type;
- Option to choose the subscribe popup featured image position;
- Option to set the subscribe popup background color;
- Option to set the subscribe popup height;
- Option to set the subscribe popup width;
- Option to set the subscribe popup close button color;
- Option to show/hide the subscribe popup close link;
- Option to set the color switcher typography for a specific page;
- WooCommerce 8.2 compatibility added;

## Updated
- Ohio Extra plugin to the 3.3.2 version;
- Main language file ohio.pot;

## Notes
- After updating to the current version, a single blog post layout might be set to Standard. 
  To change that navigate to Theme Settings > Post > General.</pre>
	</div>
</div>

<!-- Group 2cl -->
<div class="clb-group">
	<div class="clb-group-headline">
		<h3><?php _e( 'Previous Versions', 'ohio-extra' ); ?></h3>
		<a target="_blank" href="https://docs.clbthemes.com/ohio/release-notes/" class="btn btn-flat"><?php _e( 'All Changelog', 'ohio-extra' ); ?></a>
	</div>
	<table class="clb-group-content clb-group-table table-col-3 table-col-equal">
		<tbody>
			<tr>
				<td><label for="">Ver 3.3.1</label></td>
				<td>September 06, 2023</td>
				<td class="text-right"><a target="_blank" href="https://docs.clbthemes.com/ohio/release-notes/#version3.3.1"><?php _e( 'View Changelog', 'ohio-extra' ); ?></a></td>
			</tr>
			<tr>
				<td><label for="">Ver 3.3.0</label></td>
				<td>September 05, 2023</td>
				<td class="text-right"><a target="_blank" href="https://docs.clbthemes.com/ohio/release-notes/#version3.3.0"><?php _e( 'View Changelog', 'ohio-extra' ); ?></a></td>
			</tr>
			<tr>
				<td><label for="">Ver 3.2.6</label></td>
				<td>June 09, 2023</td>
				<td class="text-right"><a target="_blank" href="https://docs.clbthemes.com/ohio/release-notes/#version3.2.6"><?php _e( 'View Changelog', 'ohio-extra' ); ?></a></td>
			</tr>
		</tbody>
	</table>
</div>
