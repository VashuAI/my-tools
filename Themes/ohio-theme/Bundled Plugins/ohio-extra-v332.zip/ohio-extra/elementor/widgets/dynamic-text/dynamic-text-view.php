<div class="ohio-widget dynamic-text <?php echo $this->getWrapperClasses(); ?>" id="<?php echo $unique_id; ?>" data-dynamic-text="true" data-dynamic-text-options='<?php echo $options_json; ?>'>
    <?php echo $settings['before_text']; ?> <span class="dynamic"></span> <?php echo $settings['after_text']; ?>
</div>