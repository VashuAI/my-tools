<?php 

defined( 'ABSPATH' ) || die();

require_once WCF_ADDONS_PATH . 'inc/layout-import-api.php';
require_once WCF_ADDONS_PATH . 'inc/library-source.php';