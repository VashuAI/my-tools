<?php
/**
 * Footer Template
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<?php do_action( 'wcf_footer_builder_content' ); ?>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
